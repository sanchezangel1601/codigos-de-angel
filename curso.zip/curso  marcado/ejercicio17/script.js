const subredditContainer = document.getElementById('subreddit-container');
const addSubredditButton = document.getElementById('add-subreddit');
const modal = document.getElementById('modal');
const closeModal = document.querySelector('.close');
const subredditInput = document.getElementById('subreddit-input');
const submitSubredditButton = document.getElementById('submit-subreddit');

// Función para obtener datos del subreddit
async function fetchSubredditData(subreddit) {
    try {
        let response = await fetch(`https://www.reddit.com/r/${subreddit}.json`);
        if (!response.ok) throw new Error('Subreddit no encontrado');
        let data = await response.json();
        displaySubreddit(data.data.children, subreddit);
    } catch (error) {
        alert(error.message);
    }
}

// Función para mostrar las publicaciones del subreddit
function displaySubreddit(posts, subreddit) {
    const subredditDiv = document.createElement('div');
    subredditDiv.classList.add('subreddit');
    subredditDiv.innerHTML = `<h2>/r/${subreddit}</h2>`;
    posts.forEach(post => {
        const postDiv = document.createElement('div');
        postDiv.innerHTML = `<h3>${post.data.title}</h3>
                            <p>Autor: ${post.data.author} | Votos: ${post.data.ups}</p>`;
        subredditDiv.appendChild(postDiv);
    });
    subredditContainer.appendChild(subredditDiv);
}

// Manejar la apertura del modal
addSubredditButton.onclick = function() {
    modal.style.display = "block";
};

// Manejar el cierre del modal
closeModal.onclick = function() {
    modal.style.display = "none";
};

window.onclick = function(event) {
    if (event.target === modal) {
        modal.style.display = "none";
    }
};

// Manejar el envío del subreddit
submitSubredditButton.onclick = function() {
    const subreddit = subredditInput.value.trim();
    if (subreddit) {
        fetchSubredditData(subreddit);
        subredditInput.value = '';
        modal.style.display = "none";
    }
};

// Cargar subreddits guardados
function loadSubreddits() {
    const savedSubreddits = JSON.parse(localStorage.getItem('subreddits')) || [];
    savedSubreddits.forEach(fetchSubredditData);
}

// Guardar subreddit en localStorage
function saveSubreddit(subreddit) {
    const savedSubreddits = JSON.parse(localStorage.getItem('subreddits')) || [];
    if (!savedSubreddits.includes(subreddit)) {
        savedSubreddits.push(subreddit);
        localStorage.setItem('subreddits', JSON.stringify(savedSubreddits));
    }
}

// Cargar los subreddits al iniciar
loadSubreddits();
