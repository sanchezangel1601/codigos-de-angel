document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('temperature-form');
    const tempValue = document.getElementById('tempValue');
    const fromUnit = document.getElementById('fromUnit');
    const toUnit = document.getElementById('toUnit');
    const convertBtn = document.getElementById('convertBtn');
    const result = document.getElementById('result');

    // Habilitar el botón de convertir si todos los campos están completos
    form.addEventListener('input', () => {
        convertBtn.disabled = !(tempValue.value && fromUnit.value && toUnit.value);
    });

    // Función para convertir la temperatura
    function convertTemperature(value, from, to) {
        let celsius;

        // Convertir a Celsius como base
        if (from === 'C') {
            celsius = value;
        } else if (from === 'F') {
            celsius = (value - 32) * 5 / 9;
        } else if (from === 'K') {
            celsius = value - 273.15;
        }

        // Convertir de Celsius a la unidad de destino
        if (to === 'C') {
            return celsius;
        } else if (to === 'F') {
            return (celsius * 9 / 5) + 32;
        } else if (to === 'K') {
            return celsius + 273.15;
        }
    }

    // Manejar el evento de conversión
    form.addEventListener('submit', (event) => {
        event.preventDefault();
        const value = parseFloat(tempValue.value);
        const from = fromUnit.value;
        const to = toUnit.value;

        const convertedValue = convertTemperature(value, from, to);
        result.textContent = `Resultado: ${convertedValue.toFixed(2)} ${to}`;
    });
});
