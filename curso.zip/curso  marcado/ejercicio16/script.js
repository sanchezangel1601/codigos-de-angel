// Variables para los elementos del DOM
const languageSelect = document.getElementById('language-select');
const emptyState = document.getElementById('empty-state');
const loadingState = document.getElementById('loading-state');
const errorState = document.getElementById('error-state');
const repositoryInfo = document.getElementById('repository-info');
const retryButton = document.getElementById('retry-button');
const refreshButton = document.getElementById('refresh-button');

// Variables para mostrar información del repositorio
const repoName = document.getElementById('repo-name');
const repoDescription = document.getElementById('repo-description');
const repoStars = document.getElementById('repo-stars');
const repoForks = document.getElementById('repo-forks');
const repoIssues = document.getElementById('repo-issues');

// Función para buscar un repositorio aleatorio en GitHub
async function fetchRandomRepository(language) {
    const url = `https://api.github.com/search/repositories?q=language:${language}&sort=stars&order=desc`;
    
    // Cambiar el estado a "cargando"
    showLoadingState();

    try {
        const response = await fetch(url);
        const data = await response.json();

        // Seleccionar un repositorio aleatorio del resultado
        const randomIndex = Math.floor(Math.random() * data.items.length);
        const repository = data.items[randomIndex];

        // Mostrar los detalles del repositorio
        displayRepository(repository);
    } catch (error) {
        // Si ocurre un error, mostrar el estado de error
        showErrorState();
    }
}

// Función para mostrar los detalles del repositorio
function displayRepository(repo) {
    repoName.textContent = repo.name;
    repoDescription.textContent = repo.description || 'No description available.';
    repoStars.textContent = repo.stargazers_count;
    repoForks.textContent = repo.forks_count;
    repoIssues.textContent = repo.open_issues_count;

    // Mostrar el estado de éxito
    showSuccessState();
}

// Funciones para mostrar los diferentes estados
function showEmptyState() {
    emptyState.style.display = 'block';
    loadingState.style.display = 'none';
    errorState.style.display = 'none';
    repositoryInfo.style.display = 'none';
}

function showLoadingState() {
    emptyState.style.display = 'none';
    loadingState.style.display = 'block';
    errorState.style.display = 'none';
    repositoryInfo.style.display = 'none';
}

function showErrorState() {
    emptyState.style.display = 'none';
    loadingState.style.display = 'none';
    errorState.style.display = 'block';
    repositoryInfo.style.display = 'none';
}

function showSuccessState() {
    emptyState.style.display = 'none';
    loadingState.style.display = 'none';
    errorState.style.display = 'none';
    repositoryInfo.style.display = 'block';
}

// Evento cuando se selecciona un lenguaje
languageSelect.addEventListener('change', () => {
    const selectedLanguage = languageSelect.value;
    if (selectedLanguage) {
        fetchRandomRepository(selectedLanguage);
    }
});

// Evento para reintentar en caso de error
retryButton.addEventListener('click', () => {
    const selectedLanguage = languageSelect.value;
    if (selectedLanguage) {
        fetchRandomRepository(selectedLanguage);
    }
});

// Evento para refrescar el repositorio
refreshButton.addEventListener('click', () => {
    const selectedLanguage = languageSelect.value;
    if (selectedLanguage) {
        fetchRandomRepository(selectedLanguage);
    }
});

// Mostrar el estado vacío inicialmente
showEmptyState();
