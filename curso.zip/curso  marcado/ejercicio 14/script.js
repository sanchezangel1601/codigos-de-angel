document.addEventListener("DOMContentLoaded", function() {
  const menuBtn = document.getElementById("menuBtn");
  const menuContent = document.getElementById("menuContent");

  menuBtn.addEventListener("click", function() {
      menuContent.classList.toggle("show");
  });

  // Cerrar el menú al seleccionar un elemento
  menuContent.addEventListener("click", function(event) {
      if (event.target.tagName === 'A') {
          menuContent.classList.remove("show");
          menuBtn.textContent = event.target.textContent; // Cambiar el texto del botón al seleccionado
      }
  });
});

// Ocultar el menú si se hace clic fuera de él
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
      const dropdowns = document.getElementsByClassName("dropdown-content");
      for (let i = 0; i < dropdowns.length; i++) {
          const openDropdown = dropdowns[i];
          if (openDropdown.classList.contains('show')) {
              openDropdown.classList.remove('show');
          }
      }
  }
}
