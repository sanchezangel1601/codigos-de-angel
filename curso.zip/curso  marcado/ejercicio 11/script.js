// Function to check if the user already accepted cookies
function checkCookieConsent() {
  return localStorage.getItem("cookieConsent") === "true";
}

// Function to show the cookie popup
function showCookiePopup() {
  const popup = document.getElementById("cookie-popup");
  popup.style.display = "flex";
}

// Function to hide the cookie popup and save the consent
function acceptCookies() {
  localStorage.setItem("cookieConsent", "true");
  const popup = document.getElementById("cookie-popup");
  const thumbsUp = document.getElementById("thumbs-up");

  // Show the thumbs-up icon
  thumbsUp.style.display = "block";
  thumbsUp.style.opacity = "1"; // Make it visible

  // Trigger animation
  thumbsUp.style.animation = "thumbs-up-animation 30s forwards"; // Start animation

  // Hide the thumbs-up icon and popup after the animation
  setTimeout(() => {
      thumbsUp.style.display = "none"; // Hide the thumbs-up icon
      popup.style.display = "none"; // Hide the popup
  }, 1000); // Match this duration with the CSS animation duration
}

// Event listener for when the user accepts cookies
document
  .getElementById("accept-cookies")
  .addEventListener("click", acceptCookies);

// Check if the user has already accepted cookies
if (!checkCookieConsent()) {
  showCookiePopup();
}
