// Array para almacenar las tareas
let tasks = [];

// Referencias al DOM
const taskInput = document.getElementById('task-input');
const taskList = document.getElementById('task-list');

// Evento para agregar una nueva tarea al presionar Enter
taskInput.addEventListener('keypress', function(event) {
    if (event.key === 'Enter' && taskInput.value.trim() !== '') {
        addTask(taskInput.value.trim());
        taskInput.value = ''; // Limpiar el campo de entrada
    }
});

// Función para agregar una nueva tarea
function addTask(description) {
    const newTask = {
        description: description,
        completed: false
    };
    tasks.push(newTask);
    renderTasks();
}

// Función para renderizar las tareas en el DOM
function renderTasks() {
    // Limpiar la lista de tareas en el DOM
    taskList.innerHTML = '';

    // Mover tareas completadas al final
    const pendingTasks = tasks.filter(task => !task.completed);
    const completedTasks = tasks.filter(task => task.completed);

    // Concatenar listas de pendientes y completadas
    const orderedTasks = [...pendingTasks, ...completedTasks];

    // Renderizar cada tarea
    orderedTasks.forEach((task, index) => {
        const taskItem = document.createElement('li');
        taskItem.classList.add('task-item');
        if (task.completed) {
            taskItem.classList.add('completed');
        }

        // Checkbox para marcar completada/no completada
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = task.completed;
        checkbox.addEventListener('change', () => toggleCompleteTask(index));

        // Texto de la tarea
        const taskText = document.createElement('span');
        taskText.textContent = task.description;

        // Botón de eliminar tarea
        const deleteButton = document.createElement('button');
        deleteButton.innerHTML = '🗑️';
        deleteButton.addEventListener('click', () => deleteTask(index));

        // Agregar elementos a la tarea
        taskItem.appendChild(checkbox);
        taskItem.appendChild(taskText);
        taskItem.appendChild(deleteButton);

        // Agregar la tarea al DOM
        taskList.appendChild(taskItem);
    });
}

// Función para alternar el estado completado de una tarea
function toggleCompleteTask(index) {
    tasks[index].completed = !tasks[index].completed;
    renderTasks();
}

// Función para eliminar una tarea
function deleteTask(index) {
    tasks.splice(index, 1);
    renderTasks();
}
