function mostrarFormulario() {
    var operacion = document.getElementById('operacion').value;
    var figura = document.getElementById('figura');
    var labelFigura = document.getElementById('labelFigura');
    
    // Mostrar u ocultar el menú de figuras basado en la operación seleccionada
    if (operacion) {
        figura.style.display = 'inline';
        labelFigura.style.display = 'inline';
    } else {
        figura.style.display = 'none';
        labelFigura.style.display = 'none';
        ocultarFormularios();
    }
}

function mostrarFormularioFigura() {
    var figura = document.getElementById('figura').value;
    ocultarFormularios();
    
    if (figura) {
        document.getElementById('form' + capitalize(figura)).style.display = 'block';
    }
}

function ocultarFormularios() {
    document.getElementById('formCirculo').style.display = 'none';
    document.getElementById('formCuadrado').style.display = 'none';
    document.getElementById('formRectangulo').style.display = 'none';
    document.getElementById('formTriangulo').style.display = 'none';
}

function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function calcular() {
    var operacion = document.getElementById('operacion').value;
    var figura = document.getElementById('figura').value;
    var resultado;
    
    switch (figura) {
        case 'circulo':
            var radio = parseFloat(document.getElementById('radio').value);
            if (isNaN(radio) || radio <= 0) {
                alert("Por favor, ingresa un radio válido.");
                return;
            }
            resultado = operacion === 'area' 
                ? Math.PI * Math.pow(radio, 2) 
                : 2 * Math.PI * radio;
            document.getElementById('resultado').innerText = `${operacion === 'area' ? 'Área' : 'Perímetro'} del círculo: ${resultado.toFixed(2)}`;
            break;
        case 'cuadrado':
            var lado = parseFloat(document.getElementById('ladoCuadrado').value);
            if (isNaN(lado) || lado <= 0) {
                alert("Por favor, ingresa un lado válido.");
                return;
            }
            resultado = operacion === 'area' 
                ? Math.pow(lado, 2) 
                : 4 * lado;
            document.getElementById('resultado').innerText = `${operacion === 'area' ? 'Área' : 'Perímetro'} del cuadrado: ${resultado.toFixed(2)}`;
            break;
        case 'rectangulo':
            var base = parseFloat(document.getElementById('baseRectangulo').value);
            var altura = parseFloat(document.getElementById('alturaRectangulo').value);
            if (isNaN(base) || base <= 0 || isNaN(altura) || altura <= 0) {
                alert("Por favor, ingresa valores válidos para base y altura.");
                return;
            }
            resultado = operacion === 'area' 
                ? base * altura 
                : 2 * (base + altura);
            document.getElementById('resultado').innerText = `${operacion === 'area' ? 'Área' : 'Perímetro'} del rectángulo: ${resultado.toFixed(2)}`;
            break;
        case 'triangulo':
            var base = parseFloat(document.getElementById('baseTriangulo').value);
            var altura = parseFloat(document.getElementById('alturaTriangulo').value);
            if (isNaN(base) || base <= 0 || isNaN(altura) || altura <= 0) {
                alert("Por favor, ingresa valores válidos para base y altura.");
                return;
            }
            // Asumimos un triángulo equilátero para perímetro
            var perimetro = 3 * base;
            resultado = operacion === 'area' 
                ? 0.5 * base * altura 
                : perimetro;
            document.getElementById('resultado').innerText = `${operacion === 'area' ? 'Área' : 'Perímetro'} del triángulo: ${resultado.toFixed(2)}`;
            break;
        default:
            alert("Selecciona una figura válida.");
            break;
    }
}

function limpiarResultado() {
    // Limpia el resultado
    document.getElementById('resultado').innerText = '';

    // Limpia los campos de entrada sin cambiar las selecciones actuales
    var inputs = document.querySelectorAll('#formCirculo input, #formCuadrado input, #formRectangulo input, #formTriangulo input');
    inputs.forEach(function(input) {
        input.value = '';
    });
}function mostrarFormulario() {
    const operacion = document.getElementById('operacion').value;
    const figura = document.getElementById('figura');
    const labelFigura = document.getElementById('labelFigura');
    
    if (operacion) {
        labelFigura.style.display = 'block';
        figura.style.display = 'block';
    } else {
        labelFigura.style.display = 'none';
        figura.style.display = 'none';
        ocultarFormularios();
    }
}

function mostrarFormularioFigura() {
    const figura = document.getElementById('figura').value;
    ocultarFormularios();
    
    if (figura) {
        document.getElementById('form' + capitalizeFirstLetter(figura)).style.display = 'block';
    }
}

function ocultarFormularios() {
    document.getElementById('formCirculo').style.display = 'none';
    document.getElementById('formCuadrado').style.display = 'none';
    document.getElementById('formRectangulo').style.display = 'none';
    document.getElementById('formTriangulo').style.display = 'none';
}



function limpiarResultado() {
    document.getElementById('resultado').innerText = "";
    const inputs = document.querySelectorAll('input[type="number"]');
    inputs.forEach(input => {
        input.value = "";
    });
}

function principio() {
    document.getElementById('operacion').value = "";
    document.getElementById('figura').value = "";
    document.getElementById('labelFigura').style.display = 'none';
    document.getElementById('figura').style.display = 'none';
    ocultarFormularios();
    limpiarResultado();
}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}


